<template>
    <div>
      <Fashion />
    </div>
  </template>
  
  <script>
import Fashion from '../pages/shop/fashion/index.vue'
export default {
    components: {
      Fashion
    },
    
  }
  </script>