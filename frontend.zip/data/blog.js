export const BlogData = [
    {
        type: "fashion",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '25 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "pets",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "pets",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "pets",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "pets",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '25 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '29 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '25 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "flower",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "flower",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "flower",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "vegetables",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "vegetables",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "vegetables",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "vegetables",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "nursery",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "nursery",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "nursery",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "marijuana",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "marijuana",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "marijuana",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/images/10.jpg',
        link: '/blog/details',
        title: '26 January 2022',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }
]
