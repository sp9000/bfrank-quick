export const defaultLocale = "en";
export const localeOptions = [
    { id: 'en', name: 'English', icon: 'us' },
    { id: 'es', name: 'Spanish', icon: 'es' },
    { id: 'pt', name: 'Portuguese', icon: 'pt' },
    { id: 'fr', name: 'French', icon: 'fr' },
];